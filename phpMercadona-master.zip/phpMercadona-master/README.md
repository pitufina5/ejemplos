# phpMercadona
Ejemplo de proyecto muy básico sobre un supermercado con productos, clientes y empleados

El principal es mercadona.php, donde se llama a los métodos de las distintas clases. La clase Tienda es la que engloba todo.
