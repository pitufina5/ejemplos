# phpInvernadero
Uso de clases, jerarquía, sobrecarga, DateTime y strtotime (fechas)
